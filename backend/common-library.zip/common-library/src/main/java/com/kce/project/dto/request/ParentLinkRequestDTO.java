package com.kce.project.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ParentLinkRequestDTO {

    @NotNull(message = "Parent User ID is required")
    private Long parentUserId;

    @Email(message = "Invalid student email")
    @NotBlank(message = "Student email is required")
    private String studentEmail;

    @NotBlank(message = "Parent access code is required")
    private String accessCode;

    private String occupation;
    private String relationship;
}
