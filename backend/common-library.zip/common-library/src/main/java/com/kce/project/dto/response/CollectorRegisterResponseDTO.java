package com.kce.project.dto.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CollectorRegisterResponseDTO {
    private Long userId;
    private String fullName;
    private String email;
    private String generatedPassword;
}
