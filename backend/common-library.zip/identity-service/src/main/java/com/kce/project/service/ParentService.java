package com.kce.project.service;

import com.kce.project.dto.request.ParentLinkRequestDTO;
import com.kce.project.payload.ApiResponse;

public interface ParentService {
    ApiResponse linkChild(ParentLinkRequestDTO request);
}
