package com.kce.project.service;

import com.kce.project.dto.request.CollectorRegisterRequestDTO;
import com.kce.project.dto.response.CollectorRegisterResponseDTO;

import com.kce.project.dto.response.AdminDashboardResponseDTO;

public interface AdminDashboardService {

    AdminDashboardResponseDTO getDashboard();


    java.util.List<com.kce.project.entity.User> getPendingTeachers();
    void approveTeacher(Long userId);
    void rejectTeacher(Long userId);

    CollectorRegisterResponseDTO createCollector(CollectorRegisterRequestDTO request);
}
