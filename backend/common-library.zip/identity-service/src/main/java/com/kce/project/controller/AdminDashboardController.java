package com.kce.project.controller;

import com.kce.project.dto.request.CollectorRegisterRequestDTO;
import com.kce.project.dto.response.CollectorRegisterResponseDTO;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kce.project.dto.response.AdminDashboardResponseDTO;
import com.kce.project.service.AdminDashboardService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/admin/dashboard")
@RequiredArgsConstructor
public class AdminDashboardController {

    private final AdminDashboardService dashboardService;

    @GetMapping
    public ResponseEntity<AdminDashboardResponseDTO> getDashboard() {

        return ResponseEntity.ok(
                dashboardService.getDashboard());

    }

    @GetMapping("/teachers/pending")
    public ResponseEntity<java.util.List<com.kce.project.entity.User>> getPendingTeachers() {
        return ResponseEntity.ok(dashboardService.getPendingTeachers());
    }

    @PutMapping("/teachers/{userId}/approve")
    public ResponseEntity<com.kce.project.payload.ApiResponse> approveTeacher(@PathVariable Long userId) {
        dashboardService.approveTeacher(userId);
        return ResponseEntity.ok(new com.kce.project.payload.ApiResponse(true, "Teacher approved successfully.", null));
    }

    @DeleteMapping("/teachers/{userId}/reject")
    public ResponseEntity<com.kce.project.payload.ApiResponse> rejectTeacher(@PathVariable Long userId) {
        dashboardService.rejectTeacher(userId);
        return ResponseEntity.ok(new com.kce.project.payload.ApiResponse(true, "Teacher registration rejected.", null));
    }

    @PostMapping("/collectors")
    public ResponseEntity<CollectorRegisterResponseDTO> createCollector(
            @Valid @RequestBody CollectorRegisterRequestDTO request) {
        return ResponseEntity.ok(dashboardService.createCollector(request));
    }
}
