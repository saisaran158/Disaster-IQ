package com.kce.project.service.impl;

import com.kce.project.dto.request.ParentLinkRequestDTO;
import com.kce.project.entity.Parent;
import com.kce.project.entity.Student;
import com.kce.project.entity.User;
import com.kce.project.exception.ResourceNotFoundException;
import com.kce.project.exception.BadRequestException;
import com.kce.project.payload.ApiResponse;
import com.kce.project.repository.ParentRepository;
import com.kce.project.repository.StudentRepository;
import com.kce.project.repository.UserRepository;
import com.kce.project.service.ParentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class ParentServiceImpl implements ParentService {

    private final ParentRepository parentRepository;
    private final UserRepository userRepository;
    private final StudentRepository studentRepository;

    @Override
    public ApiResponse linkChild(ParentLinkRequestDTO request) {
        User parentUser = userRepository.findById(request.getParentUserId())
                .orElseThrow(() -> new ResourceNotFoundException("Parent User not found"));

        User studentUser = userRepository.findByEmail(request.getStudentEmail())
                .orElseThrow(() -> new ResourceNotFoundException("Student User not found with email: " + request.getStudentEmail()));

        Student student = studentRepository.findByUserUserId(studentUser.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("Student profile not found for email: " + request.getStudentEmail()));

        if (student.getParentAccessCode() == null || !student.getParentAccessCode().equalsIgnoreCase(request.getAccessCode())) {
            throw new BadRequestException("Invalid parent access code");
        }

        if (parentRepository.existsByUserUserId(parentUser.getUserId())) {
            throw new BadRequestException("Parent account is already linked to a student");
        }

        Parent parent = Parent.builder()
                .user(parentUser)
                .student(student)
                .occupation(request.getOccupation())
                .relationship(request.getRelationship())
                .build();

        parentRepository.save(parent);
        return new ApiResponse(true, "Child linked successfully!", null);
    }
}
