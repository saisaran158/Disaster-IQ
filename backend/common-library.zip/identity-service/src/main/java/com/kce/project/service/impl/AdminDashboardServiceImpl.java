package com.kce.project.service.impl;

import com.kce.project.dto.request.CollectorRegisterRequestDTO;
import com.kce.project.dto.response.CollectorRegisterResponseDTO;
import com.kce.project.entity.User;
import com.kce.project.enums.Role;
import com.kce.project.exception.ResourceAlreadyExistsException;
import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.stereotype.Service;

import com.kce.project.dto.response.AdminDashboardResponseDTO;
import com.kce.project.enums.Role;
import com.kce.project.repository.AssessmentRepository;
import com.kce.project.repository.AssignmentRepository;
import com.kce.project.repository.SchoolClassRepository;
import com.kce.project.repository.SchoolRepository;
import com.kce.project.repository.SimulationRepository;
import com.kce.project.repository.StudentRepository;
import com.kce.project.repository.TeacherRepository;
import com.kce.project.repository.UserRepository;
import com.kce.project.service.AdminDashboardService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AdminDashboardServiceImpl implements AdminDashboardService {

	private final UserRepository userRepository;
	private final PasswordEncoder passwordEncoder;

	private final SchoolRepository schoolRepository;

	private final TeacherRepository teacherRepository;

	private final StudentRepository studentRepository;

	private final SchoolClassRepository classRepository;

	private final SimulationRepository simulationRepository;

	private final AssignmentRepository assignmentRepository;

	private final AssessmentRepository assessmentRepository;

    @Override
    public AdminDashboardResponseDTO getDashboard() {

        return AdminDashboardResponseDTO.builder()

                .totalUsers(userRepository.count())

                .totalSchools(schoolRepository.count())

                .totalTeachers(userRepository.countByRole(Role.TEACHER))

                .totalStudents(userRepository.countByRole(Role.STUDENT))

                .totalParents(userRepository.countByRole(Role.PARENT))

                .totalCollectors(userRepository.countByRole(Role.COLLECTOR))

                .totalClasses(classRepository.count())

                .totalSimulations(simulationRepository.count())

                .totalAssignments(assignmentRepository.count())

                .totalAssessments(assessmentRepository.count())

                .build();
    }

    @Override
    public java.util.List<com.kce.project.entity.User> getPendingTeachers() {
        return userRepository.findByRoleAndActive(Role.TEACHER, false);
    }

    @Override
    @org.springframework.transaction.annotation.Transactional
    public void approveTeacher(Long userId) {
        com.kce.project.entity.User user = userRepository.findById(userId)
                .orElseThrow(() -> new com.kce.project.exception.ResourceNotFoundException("Teacher not found."));
        user.setActive(true);
        userRepository.save(user);
    }

    @Override
    @org.springframework.transaction.annotation.Transactional
    public void rejectTeacher(Long userId) {
        com.kce.project.entity.User user = userRepository.findById(userId)
                .orElseThrow(() -> new com.kce.project.exception.ResourceNotFoundException("Teacher not found."));
        userRepository.delete(user);
    }

    @Override
    @org.springframework.transaction.annotation.Transactional
    public CollectorRegisterResponseDTO createCollector(CollectorRegisterRequestDTO request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new ResourceAlreadyExistsException("Collector Email already exists.");
        }

        // Generate a random secure 16-character alphanumeric password
        String rawPassword = java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 16);

        User collector = User.builder()
                .fullName(request.getFullName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(rawPassword))
                .phone(request.getPhone())
                .role(Role.COLLECTOR)
                .active(true)
                .build();

        collector = userRepository.save(collector);

        return CollectorRegisterResponseDTO.builder()
                .userId(collector.getUserId())
                .fullName(collector.getFullName())
                .email(collector.getEmail())
                .generatedPassword(rawPassword)
                .build();
    }
}
