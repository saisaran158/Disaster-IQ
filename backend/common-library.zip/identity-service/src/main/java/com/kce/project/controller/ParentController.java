package com.kce.project.controller;

import com.kce.project.dto.request.ParentLinkRequestDTO;
import com.kce.project.payload.ApiResponse;
import com.kce.project.service.ParentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/parents")
@RequiredArgsConstructor
public class ParentController {

    private final ParentService parentService;

    @PostMapping("/link")
    public ResponseEntity<ApiResponse> linkChild(@Valid @RequestBody ParentLinkRequestDTO request) {
        return ResponseEntity.ok(parentService.linkChild(request));
    }
}
